

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header"><i class="fa fa-align-justify"></i>رسائل التواصل</div>
            <div class="card-body">
                <?php if(count($msgs) > 0): ?>
                <?php $__currentLoopData = $msgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="resume-item">
                    <table>
                        <tr>
                            <td>التاريخ</td>
                            <td><?php echo e($msg->created_at); ?></td>
                        </tr>

                        <tr>
                            <td>الاسم</td>
                            <td><?php echo e($msg->name); ?></td>
                        </tr>

                        <tr>
                            <td>البريد الالكتروني</td>
                            <td><?php echo e($msg->email); ?></td>
                        </tr>

                        <tr>
                            <td>العنوان</td>
                            <td><?php echo e($msg->subject); ?></td>
                        </tr>

                        <tr>
                            <td>الرسالة</td>
                            <td><?php echo e($msg->message); ?></td>
                        </tr>

                    </table>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div style="text-align: center">
                    <img height="80" src="/admin/assets/img/box.svg" alt="">
                    <h3 style="margin-top:0">لا يوجد</h3>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- /.col-->
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h725atbdxjx4/office_website/resources/views/admin/contactMessages.blade.php ENDPATH**/ ?>