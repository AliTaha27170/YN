

<?php $__env->startSection('content'); ?>

<script>
    $("nav").addClass("scrolled");
    $(".n-career").addClass("n-active")
</script>

<link rel="stylesheet" href="/css/career.css">
<link rel="stylesheet" href="/libs/accordion/css/aria.accordion.css">

<div class="career-header">
    <div class="career-header-box">
        <h1><?php echo e(__('career.Join_our_team')); ?></h1>
    </div>

</div>

<div class="career-box">
    <h1><?php echo e(__('career.Be_one_of_us')); ?></h1>
    <?php if(Session::has("isSuccess")): ?>
        <?php if(Session::get("isSuccess")): ?>
        <div class="succ-msg">
            <?php echo e(__('career.received_your_request')); ?>

                </div>
        <?php else: ?>
        <div class="error-msg">
            <?php echo e(__('career.all_fields')); ?>

        </div>
        <?php endif; ?>
    <?php endif; ?>

    <div class="send-cv-box">
        <div class="row">
            <div class="col-md-7">
                <form action="postJobRequest" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="name" class="input1" placeholder="    <?php echo e(__('career.fullName')); ?> ">
                    <br><br>
                    <input type="text" name="email" class="input1" placeholder="   <?php echo e(__('career.email')); ?> ">
                    <br><br>
                    <input type="text" name="phone" class="input1" placeholder="  <?php echo e(__('career.phone')); ?>">
                    <br><br>
                    <input type="text" name="job" class="input1" placeholder="<?php echo e(__('career.jop')); ?>">
                    <br><br>
                    <textarea type="text" name="about" class="input1" placeholder=" <?php echo e(__('career.about_yourself')); ?> "></textarea>
                    <br><br>
                    <div class="input1">
                        <?php echo e(__('career.cv')); ?> &nbsp;&nbsp;<input name="resume" class="input1" type="file">
                    </div>
                    <br>
                    <div style="text-align: center;">
                        <button class="btn1" href="#"> <?php echo e(__('career.send')); ?> </button>
                    </div>
                </form>
            </div>

            <div class="col-md-5 career-creative-box">
                <h3> <?php echo e(__('career.creative')); ?>  </h3>
                <p> <?php echo e($text->find(47)->$local); ?></p>
                <button class="go-jobs"> <?php echo e(__('career.continue')); ?></button>
            </div>
        </div>
    </div>
    
    <br>
    <hr style="opacity: 0.3">
    <div class="jobs-box">
        <div class="jobs-parent">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="title"><?php echo e(__('career.jobs')); ?></h2>
                    <?php if(count($jobs) > 0): ?>
                        
                    <div data-aria-accordion data-transition id="accGen">

                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h3 data-aria-accordion-heading>
                                <?php echo e($job->title); ?>

                            </h3>
                            <div data-aria-accordion-panel>
                                <p>
                                <span class="job-location"><img src="/img/icons/marker.svg" width="20">&nbsp;<?php echo e($job->location); ?></span>
                                    <?php echo $job->description; ?>

                                </p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    
                    <?php else: ?>
                        <div style="text-align: center">
                            <img height="80" src="/admin/assets/img/box.svg" alt="">
                            <h3><?php echo e(__('career.noJops')); ?> </h3>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <br>
    </div>
</div>
<script>
    $(".go-jobs").click(function() {
        $('html, body').animate({
            scrollTop: $(".jobs-box").offset().top - 110
        }, 1500);
    });
</script>
<br><br>
<script src="/libs/accordion/js/aria.accordion.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h725atbdxjx4/office_website/resources/views/career.blade.php ENDPATH**/ ?>