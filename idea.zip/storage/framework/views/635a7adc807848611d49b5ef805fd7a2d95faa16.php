

<?php $__env->startSection('content'); ?>


<script>
    $("nav").addClass("scrolled");
    $(".n-about").addClass("n-active")
</script>

<link rel="stylesheet" href="/css/career.css">

<div style="background-image: url('/img/contact_bg.jpg')" class="career-header">
    <div class="career-header-box">
        <h1><?php echo e(__('about.who_are_we')); ?> </h1>
    </div>

</div>

<div class="career-box about-box">
    <br>
    <img src="/img/logo.svg" class="about-logo">
    <br>
    <h3><?php echo e(__('about.Yehia')); ?></h3>
    <p><?php echo e($text->find(56)->$local); ?></p>
</div>

<br><br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ali Taha\Desktop\najib-office\resources\views/about.blade.php ENDPATH**/ ?>