

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header"><i class="fa fa-align-justify"></i>الوظائف الشاغرة</div>
            <div class="card-body">
                <?php if(count($jobs) > 0): ?>
                <table class="table table-responsive-sm table-bordered table-striped table-sm m-data-table">
                    <thead>
                        <tr>
                            <th>العنوان</th>
                            <th>المكان</th>
                            <th>تاريخ الإضافة</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>


                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($job->title); ?></td>
                            <td><?php echo e($job->location); ?></td>
                            <td><?php echo e($job->created_at); ?></td>
                            <td class="btns-control">
                                <a href="/manage/jobs/<?php echo e($job->id); ?>/edit" class="edit-btn"><img
                                        src="/admin/assets/img/edit.svg" alt=""></a>
                                <a onclick="deleteJob(<?php echo e($job->id); ?>)" class="delete-btn"><img
                                        src="/admin/assets/img/delete.svg" alt=""></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
                <?php else: ?>
                    <div style="text-align: center">
                        <img height="80" src="/admin/assets/img/box.svg" alt="">
                        <h3 style="margin-top:0">لا يوجد</h3>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- /.col-->
</div>

<div>
    <form id="delete-form" action="" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" value="DELETE">
    </form>
</div>

<script>
    function deleteJob(id) {
        if (confirm('هل انت متأكد من الحذف')) {
            $("#delete-form").attr("action", "/manage/jobs/" + id);
            $("#delete-form").submit();
        }
    }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ali Taha\Desktop\najib-office\resources\views/admin/jobsIndex.blade.php ENDPATH**/ ?>