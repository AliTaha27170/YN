

<?php $__env->startSection('content'); ?>


<script>
    $("nav").addClass("scrolled");
    $(".n-contact").addClass("n-active")
</script>

<link rel="stylesheet" href="/css/career.css">

<div style="background-image: url('/img/contact_bg.jpg')" class="career-header">
    <div class="career-header-box">
        <h1> <?php echo e(__('contact.Connect_with_us')); ?></h1>
    </div>

</div>

<div class="career-box">
    <h1>  <?php echo e(__('contact.private_message')); ?> </h1>
    <?php if(Session::has("isSuccess")): ?>
        <?php if(Session::get("isSuccess")): ?>
        <div class="succ-msg">
            <?php echo e(__('contact.received_your_message')); ?>    
             </div>
        <?php else: ?>
        <div class="error-msg">
            <?php echo e(__('contact.all_fields')); ?>    
        </div>
        <?php endif; ?>
    <?php endif; ?>
    <div class="send-cv-box">
        <div class="row">
            <div class="col-md-7">
                <form action="<?php echo e(route('postContact')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input name="name" type="text" class="input1" placeholder=" <?php echo e(__('contact.full_name')); ?>  ">
                    <br><br>
                    <input name="email" type="text" class="input1" placeholder=" <?php echo e(__('contact.email')); ?> ">
                    <br><br>
                    <input name="subject" type="text" class="input1" placeholder="<?php echo e(__('contact.subject')); ?> ">
                    <br><br>
                    <textarea name="message" type="text" class="input1" placeholder="<?php echo e(__('contact.message')); ?>  "></textarea>
                    <br><br>
                    <div style="text-align: center;">
                        <button class="btn1"><?php echo e(__('contact.send')); ?> </button>
                    </div>
                </form>
            </div>

            <div class="col-md-5 career-creative-box">
                <h3><?php echo e(__('contact.infCon')); ?> </h3>

                <ul class="contact-info-box">
                    <li>
                        <img src="/img/icons/callFoot.svg" alt="">
                        <span class="ltr" style="display: inline-block">+963 967 204 344</span>
                    </li>
                    <li>
                        <img src="/img/icons/callFoot.svg" alt="">
                        <span class="ltr" style="display: inline-block">+963 41 257 5466</span>
                    </li>
                    <li>
                        <img src="/img/icons/atFoot.svg" alt="">
                        <span>Yehia@hopkinsvita.com</span>
                    </li>

                </ul>
            </div>
        </div>
    </div>

</div>

<br><br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h725atbdxjx4/office_website/resources/views/contact.blade.php ENDPATH**/ ?>