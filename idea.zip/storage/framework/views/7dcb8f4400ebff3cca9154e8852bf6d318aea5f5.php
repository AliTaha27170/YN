

<?php $__env->startSection('content'); ?>


<script>
    $("nav").addClass("scrolled");
    $(".n-services").addClass("n-active")
</script>

<link rel="stylesheet" href="/css/services.css">

<div class="ser-header" style="background-image: url('/img/services_bg3_rtl.jpg')">
    <div class="ser-header-box">
        <div class="row">
            <div class="col-md-5">
                <h1><?php echo e(__('services.various_services')); ?></h1>
                <p> <?php echo e($text->find(21)->$local); ?></p>
                <div style="text-align: left;">
                    <button class="btn1 continue-btn"><?php echo e(__('services.continue')); ?></button>
                </div>
            </div>

            <div class="col-md-7">

            </div>
        </div>
    </div>

</div>
<br><br>
<h1 class="page-title">
    <?php echo e(__('services.we_offer')); ?>

        <p>     <?php echo e(__('services.Main_services')); ?>        </p>
</h1>


<div class="services-parent">
    <div class="service-box">
        <img src="/img/icons/global.svg">
        <h2><?php echo e($text->find(22)->$local); ?></h2>
        <h1><?php echo e($text->find(23)->$local); ?></h1>
        <p><?php echo e($text->find(24)->$local); ?></p>
    </div>

    <div class="service-box">
        <img src="/img/icons/drug.svg">
        <h2><?php echo e($text->find(25)->$local); ?></h2>
        <h1><?php echo e($text->find(26)->$local); ?></h1>
        <p><?php echo e($text->find(27)->$local); ?></p>
    </div>

    <div class="service-box">
        <img src="/img/icons/tech.svg">
        <h2><?php echo e($text->find(28)->$local); ?></h2>
        <h1><?php echo e($text->find(29)->$local); ?></h1>
        <p><?php echo e($text->find(30)->$local); ?></p>
    </div>
</div>

<br><br>
<!-- <h1 class="page-title">
    <p>جميع خدماتنا</p>
</h1> -->
<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(is_null ($service->dad)): ?>
                <div class="service-cat-box">
                    <img src="<?php echo e($service->logo); ?>">
                    <p><?php echo e($service->$title); ?></p>
                </div>
                <div class="services-parent">

                <?php $__currentLoopData = $service->sons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $son): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="service-box2">
                        <div class="sb-header">
                            <img src="<?php echo e($son->logo); ?>">
                            <div>
                                <h1><?php echo e($son->$title); ?></h1>
                            </div>
                        </div>
                        <p><?php echo e($son->$description); ?></p>
                        </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </h1>

               
            </div>
        <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    $(".continue-btn").click(function() {
        $('html, body').animate({
            scrollTop: $(".page-title").offset().top - 110
        }, 1500);
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ali Taha\Desktop\najib-office\resources\views/services.blade.php ENDPATH**/ ?>