

<?php $__env->startSection('content'); ?>


<script>
    $("nav").addClass("scrolled");
    $(".n-phar").addClass("n-active")
</script>
<link rel="stylesheet" href="/libs/accordion/css/aria.accordion.css">
<link rel="stylesheet" href="/css/warehouse.css">

<div class="wh-header" style="background-image: url('/img/med-bg1_rtl.jpg')">
    <div class="row">
        <div class="col-lg-7">
            <div class="side-title">
                <img src="/img/capsules.svg" class="capsules-img">
                <div>
                    <h1><?php echo e(__("drug.Drug_store")); ?></h1>
                    <h1><?php echo e(__("drug.yehia")); ?></h1>
                </div>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="circles-parent">
                <div>
                    <div class="circle-item">
                        <img src="/img/icons/shield.svg">
                        <p><?php echo e(__("drug.safe")); ?></p>
                    </div>
                </div>

                <div>
                    <div class="circle-item">
                        <img src="/img/icons/tick.svg">
                        <p><?php echo e(__("drug.Quality")); ?></p>
                    </div>

                    <div class="circle-item">
                        <img src="/img/icons/global2.svg">
                        <p><?php echo e(__("drug.Global")); ?></p>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<div class="wwr-parent">
    <h1 class="page-title">
        <?php echo e(__("drug.About_drug")); ?>

    </h1>
    <br>
    <div class="wwr-box">
        <div class="row">
            <div class="col-md-6">
                <div class="img-box"></div>
            </div>

            <div class="col-md-6">
                <h2>    <?php echo e(__("drug.yehia_Drug")); ?></h2>
                <p><?php echo e($text->find(36)->$local); ?></p>
            </div>
        </div>
    </div>
</div>


<div class="st-parent">
    <h1 class="page-title">
        <?php echo e(__("drug.we_store")); ?>

    </h1>
    <br>
    <div class="st-box">
        <div class="row">
            <div class="col-md-6">
                <h2><?php echo e(__("drug.we_stok")); ?></h2>
                <p><?php echo e($text->find(37)->$local); ?></p>
            </div>
            <div class="col-md-6">
                <img src="/img/graph.svg" class="img-box" />
            </div>

        </div>
    </div>
</div>

<div class="faq-parent">
    <div class="row">
        <div class="col-md-8">
            <h2 class="title"><?php echo e(__("drug.Question_Answer")); ?></h2>
            <div data-aria-accordion data-transition id="accGen">

                <h3 data-aria-accordion-heading>
                    السؤال هنا ؟
                </h3>
                <div data-aria-accordion-panel>
                    <p>
                        هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد
                    </p>
                </div>

                <h3 data-aria-accordion-heading>
                    السؤال هنا ؟
                </h3>
                <div data-aria-accordion-panel>
                    <p>
                        هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد
                    </p>
                </div>

                <h3 data-aria-accordion-heading>
                    السؤال هنا ؟
                </h3>
                <div data-aria-accordion-panel>
                    <p>
                        هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد
                    </p>
                </div>

                <h3 data-aria-accordion-heading>
                    السؤال هنا ؟
                </h3>
                <div data-aria-accordion-panel>
                    <p>
                        هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد
                    </p>
                </div>


            </div>
        </div>

        <div class="col-md-4">
            <form class="msg-box">
                <h2><?php echo e(__("drug.looking_for")); ?> </h2>
                <h3><?php echo e(__("drug.Ask_us")); ?></h3>

                <input placeholder=" <?php echo e(__('drug.full_name')); ?> " type="text" class="input1">
                <input placeholder=" <?php echo e(__('drug.email')); ?>" type="text" class="input1">
                <textarea placeholder="  <?php echo e(__('drug.write')); ?>" class="input1"></textarea>
                <div style="text-align: center">
                    <button><?php echo e(__("drug.send")); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="/libs/accordion/js/aria.accordion.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h725atbdxjx4/office_website/resources/views/warehouse.blade.php ENDPATH**/ ?>