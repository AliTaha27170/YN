

<?php $__env->startSection('content'); ?>

<script>
    $("nav").addClass("scrolled");
    $(".n-about").addClass("n-active")
</script>

<link rel="stylesheet" href="/css/career.css">
<link rel="stylesheet" href="<?php echo e(asset('css/edit.css')); ?>">

<div style="background-image: url('/img/contact_bg.jpg')" class="career-header">
    <div class="career-header-box">
        <h1><?php echo e(__('about.who_are_we')); ?> </h1>
    </div>

</div>

<div class="career-box about-box">
    <br>
    <img src="/img/logo.svg" class="about-logo">
    <br>
    <h3><?php echo e(__('about.Yehia')); ?></h3>


    <form action="<?php echo e(route('mainPush',['from'=>56 , 'to' =>56])); ?>" method="POST">
        <?php echo e(csrf_field()); ?>



        
        <textarea class="textarea text6   ar"  name="<?php echo e($i); ?>">
   <?php echo e($text->find($i)->ar); ?> 
       </textarea>
        <textarea class="textarea text6   en"  name="<?php echo e($i.$i); ?>" style="display:none"  >
   <?php echo e($text->find($i++)->en); ?> 
       </textarea>


</div>
<center>
    <button type="submit" id="save" class="btnSave btn1">حفظ التعديلات </button>

</center>
</form>
<br><br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('directEdit.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h725atbdxjx4/office_website/resources/views/directEdit/about.blade.php ENDPATH**/ ?>