<?php
use App\Http\Controllers\editAdmin\textContorller;

$con=new textContorller;

 return [ 
      '1'=>$con->text()->find(1)-> ar,
    'welcome'                =>"أهلاً بك في  ",
    'yehia'                  =>"مؤسسة يحيى نجيب ",
    'Commercial'             =>"التجارية  ",
    'who_are_we'             =>"من نحن",
    'View_services'          =>"عرض جميع خدماتنا ",
    'look'                   =>"شاهد",
    'know_more'              =>"واعرف أكثر",
    'institution_services'   =>"خدمات مؤسستنا ",
    'Drug_store'             =>"مستودع أدوية ",
    'Get_know'               => "تعرف على مستودعنا للأدوية ",
    'Yehia_drug'             =>"مستودع يحيى نجيب للأدوية ",
    'know_more'              => "وتعرف أكثر",
    'know'                   => "تعرف أكثر",
    'Our_companies'          => "شركاتنا",
    'established'            => "تأسست",
    'Branches'               => "فروعنا",
    'Site Map'               =>'خريطة الموقع',
    'Main'                   =>'الرئيسية' ,
    'our_services'           =>'خدماتنا' ,
    'jobs'                   =>'وظائف شاغرة ' ,
    'Connect_us'             =>'تواصل معنا' ,
    'Contact_info'           =>'معلومات التواصل' ,
    'rights_reserved'        =>"جميع الحقوق محفوظة لصالح مؤسسة يحيى نجيب التجارية",
    'about_US'               =>'حولنا ' ,
    'Adress'                 =>'المكتب الرئيسي شارع هنانو, اللاذقية, سوريا',
    'jobs'                   =>'وظائف شاغرة ',
    'here'                   =>'نتواجد 6 أيام بالأسبوع 10:00 ص - 6:00 م ',
 ];
