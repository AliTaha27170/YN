<?php
use App\Http\Controllers\editAdmin\textContorller;

$con=new textContorller;

 return [ 
   'various_services'       =>"خدماتنا المتنوعة ",
   'continue'               =>"استمر",
   'we_offer'               =>"ماذا نقدم",
   'Main_services'          =>"الخدمات الرئيسية",
   'service'                =>"خدمة",
   'have'                   =>"لدينا",
   
   ];


    