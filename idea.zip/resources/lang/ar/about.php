<?php

use App\Http\Controllers\editAdmin\textContorller;

$con = new textContorller;

return [

    'who_are_we'                              => "من نحن ",
    'Yehia'                                   => "من هي مؤسسة يحيى نجيب",
    ''                                        => "",
    ''                                        => "",
    



];
