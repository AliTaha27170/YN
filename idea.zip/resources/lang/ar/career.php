<?php

use App\Http\Controllers\editAdmin\textContorller;

$con = new textContorller;

return [

    'Join_our_team'            => "انضم إلى فريقنا  ",
    'Be_one_of_us'             => "كن واحداً منا ",
    'received_your_request'    => "لقد استلمنا طلبك , سنعلمك بالنتيجة في أقرب وقت ",
    'all_fields'               => "الرجاء ملئ جميع الحقول ",
    'fullName'                 => "الاسم الكامل",
    'email'                    => "الايميل الخاص بك",
    'phone'                    => "رقم الهاتف ",
    'jop'                      => "الوظيفة المرغوبة",
    'about_yourself'           => "حدثنا عن نفسك ",
    'cv'                       => "السيرة الذاتية الخاصة بك",
    'send'                     => "إرسال",
    'creative'                 => "هل أنت مبدع ؟ ",
    'jobs'                     =>'الوظائف الشاغرة  ' ,
    'noJops'                   => "لايوجد",
    'continue'                 => "استمر",



];
