<?php

use App\Http\Controllers\editAdmin\textContorller;

$con = new textContorller;

return [
    'Connect_with_us'                         => "تواصل معنا",
    'private_message'                         => "أرسل رسالة خاصة",
    'received_your_message'                   => "لقد تلقينا رسالتك , سنتواصل معك بأقرب وقت ",
    'all_fields'                              => "الرجاء ملئ جميع الحقول ",
    'full_name'                               => "الاسم الكامل ",
    'email'                                   => "الإيميل الخاص بك",
    'message'                                 => "موضوع الرسالة",
    'subject'                                 => "العنوان",
    'send'                                    => "إرسال",
    'infCon'                                  => "معلومات التواصل",
    ''                                        => "",
    



];
