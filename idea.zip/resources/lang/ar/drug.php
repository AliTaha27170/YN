<?php

use App\Http\Controllers\editAdmin\textContorller;

$con = new textContorller;

return [

    'yehia'                  => 'يحيى نجيب',
    'Drug_store'             => "مستودع أدوية ",
    'safe'                   => "آمن ",
    'Quality'                => " جودة",
    'Global'                 => "عالمي ",
    'About_drug'             => "عن مستودع الأدوية ",
    'yehia_Drug'             => "مستودع يحيى نجيب للأدوية  ",
    'we_store'               => " ماذا نحزن ",
    'we_stok'                => "أهم أصناف الأدوية التي نخزنها  ",
    'Question_Answer'        => " سؤال و جواب",
    'looking_for'            => "ألم تجد ما تبحث عنه  ?",
    'full_name'              => "اسمك الكامل",
    'Ask_us'                 => "إسألنا برسالة خاصة  ",
    'email'                  => "الإيميل",
    'write'                  => "ضع سؤالك",
    'send'                   => " إرسال",
    ''                       => " ",



];
