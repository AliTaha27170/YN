<?php

use App\Http\Controllers\editAdmin\textContorller;

$con = new textContorller;

return [

    'yehia'                  => 'YEHIA NAJIB',
    'Drug_store'             => " Pharmaceutical Warehouse",
    'safe'                   => "Safe",
    'Quality'                => " Quality",
    'Global'                 => "Global ",
    'About_drug'             => "About a drug store",
    'yehia_Drug'             => "Yehia Najib Pharmaceutical Warehouse",
    'we_store'               => " What do we store",
    'we_stok'                => "The most important types of medicines that we stock ",
    'Question_Answer'        => " Question and Answer",
    'looking_for'            => "Can not find what you are looking for ?",
    'full_name'              => " your full name",
    'Ask_us'                 => "Ask us with a private message ",
    'email'                  => "email",
    'write'                  => "Type your question",
    'send'                   => " send",
    ''                       => " ",



];
