<?php
use App\Http\Controllers\editAdmin\textContorller;

$con=new textContorller;

 return [ 
   'various_services'       =>"Our various services  ",
   'continue'               =>"continue",
   'we_offer'               =>"What we offer",
   'Main_services'          =>"The main services",
   'service'                =>"service",
   'have'                   =>"We have",
   
   ];


    