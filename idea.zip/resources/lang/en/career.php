<?php

use App\Http\Controllers\editAdmin\textContorller;

$con = new textContorller;

return [

    'Join_our_team'            => "Join our team ",
    'Be_one_of_us'             => "Be one of us",
    'received_your_request'    => "We have received your request, we will contact you as soon as possible",
    'all_fields'               => "Please fill in all fields",
    'fullName'                 => "fullName",
    'email'                    => "email",
    'phone'                    => "phone number",
    'jop'                      => "The desired job",
    'about_yourself'           => "Talk to us about yourself",
    'cv'                       => "your CV",
    'send'                     => "send",
    'creative'                 => "Are you creative ? ",
    'jobs'                     =>'jobs vacant ' ,
    'noJops'                   => "There are no jobs now",
    'continue'                 => "continue",

    ''                         => "",



];
