<?php

use App\Http\Controllers\editAdmin\textContorller;

$con = new textContorller;

return [
    'Connect_with_us'                         => "Connect with us",
    'private_message'                         => "Send a private message",
    'received_your_message'                   => "We have received your message .. We will contact you as soon as possible",
    'all_fields'                              => "Please fill in all fields",
    'full_name'                               => "full name",
    'email'                                   => "email",
    'message'                                 => "message",
    'subject'                                 => "subject",
    'send'                                    => "send",
    'infCon'                                  => "Contact info",
    ''                                        => "",
    



];
