<?php
use App\Http\Controllers\editAdmin\textContorller;

$con=new textContorller;

 return [ 
  '11'=>$con->text()->find(1)-> en,

    'welcome'                =>"Welcome to ",
    'yehia'                  =>"YEHIA NAJIB ESTABLISHMENT",
    'Commercial'             =>" ",
    'who_are_we'             =>"Who are we",
    'View_services'          =>"View all our services",
    'look'                   =>"Look",
    'know_more'              =>"And know more",
    'institution_services'   =>"Our institution services",
    'Drug_store'             =>" Pharmaceutical 
",
    'Get_know'               => "Get to know about our  Pharmaceutical Warehouse

",
    'Yehia_drug'             =>"Yehia Najib Pharmaceutical Warehouse

",
    'know_more'              => "And know more",
    'know'                   => "know more",
    'Our_companies'          => "Our companies",
    'established'            => "was established",
    'Branches'               => "Our Branches",
    'Site_Map'               =>'Site Map',
    'Main'                   =>'Main page' ,
    'our_services'           =>'our services' ,
    'jobs'                   =>'jobs vacant ' ,
    'Connect_us'             =>'Connect with us' ,
    'Contact_info'           =>'Contact info' ,
    'rights_reserved'        =>'All rights reserved ' ,
    'about_US'               =>'About us ' ,
    'Adress'                 =>'Main office > Syria , Lattakia,  Hanano Street ',
    'jobs'                   =>'jobs vacant ',
    'here'                   =>'We are available 6 days a week from 10:00 AM - 6:00 PM

',
    

 ];
