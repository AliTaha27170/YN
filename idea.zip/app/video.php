<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class video extends Model
{
    protected $table = 'video';
    protected $guarded = [];
    public $timestamps  = false;
}
