<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TextEditing extends Model
{
    protected $table    = 'textediting';
    public $timestamps  = false;
    protected $guarded = [];
}
